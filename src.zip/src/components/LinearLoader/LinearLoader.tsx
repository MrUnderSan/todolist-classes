import './linearLoader.css'

export const LinearLoader = () => {
    console.log('LinearLoader')
    return <div className={'linearLoader'}></div>
}